<?php $__env->startSection('title', 'Dashboard DIFAS App'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-wrapper justify-content-center">

    
    <div class="row text-white mb-4">
        <div class="col-sm-12 col-md-4 mb-3">
            <div class="bg-primary p-4 rounded shadow d-flex justify-content-between align-items-center">
                <div>
                    <h6>Total Barang</h6>
                    <h2><?php echo e($totalItem); ?></h2>
                </div>
                <img src="<?php echo e(asset('logo/BARANG.png')); ?>" alt="Barang Icon" style="width: 40px; height: 40px;">
            </div>
        </div>
        <div class="col-sm-12 col-md-4 mb-3">
            <div class="bg-primary p-4 rounded shadow d-flex justify-content-between align-items-center">
                <div>
                    <h6>Total Transaksi Bulan Ini</h6>
                    <h2><?php echo e($totalTransaksi); ?></h2>
                </div>
                <img src="<?php echo e(asset('logo/TRANSAKSI.png')); ?>" alt="Transaksi Icon" style="width: 40px; height: 40px;">
            </div>
        </div>
        <div class="col-sm-12 col-md-4 mb-3">
            <div class="bg-primary p-4 rounded shadow d-flex justify-content-between align-items-center">
                <div>
                    <h6>Pendapatan Bulan Ini</h6>
                    <h2>Rp. <?php echo e(number_format($omset, 0, ',', '.')); ?></h2>
                </div>
                <img src="<?php echo e(asset('logo/PENDAPATAN.png')); ?>" alt="Pendapatan Icon" style="width: 40px; height: 40px;">
            </div>
        </div>
    </div>

    
    <div class="bg-primary p-4 rounded shadow mb-4">
        <h6 class="fw-semibold mb-3">Pesanan 7 Hari ke Depan</h6>

        <?php if($upcomingPesanan->isEmpty()): ?>
            <p class="text-mute text-white">Tidak ada pesanan dalam 7 hari ke depan.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped text-center align-middle bg-white">
                    <thead class="table-primary" style="position: sticky; top: 0;">
                        <tr>
                            <th>Tanggal Acara</th>
                            <th>Nama Pemesan</th>
                            <th>No. Telepon</th>
                            <th>Alamat</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $upcomingPesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr onclick="window.location='<?php echo e(route('invoice.show', $pesanan->id)); ?>';" style="cursor:pointer;">
                                <td><?php echo e(\Carbon\Carbon::parse($pesanan->tanggal_acara)->translatedFormat('d M Y')); ?></td>
                                <td><?php echo e($pesanan->nama_pemesan); ?></td>
                                <td><?php echo e($pesanan->no_telepon); ?></td>
                                <td><?php echo e($pesanan->alamat); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($pesanan->status == 'Selesai' ? 'success' : 'warning'); ?>">
                                        <?php echo e($pesanan->status); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>


    
    <div class="row mb-4">
        <div class="col-sm-12 col-md-6 mb-3">
            <div class="bg-primary p-4 rounded shadow text-white">
                <h6>Statistik Kategori</h6>
                <div style="position: relative; height:300px;">
                    <canvas id="kategoriChart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-sm-12 col-md-6 mb-3">
            <div class="bg-primary p-4 rounded shadow text-white">
                <h6>Statistik Barang</h6>
                <div style="position: relative; height:300px;">
                    <canvas id="barangChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    
    <div class="bg-primary p-4 rounded shadow text-white mb-3">
        <h6>Data Penyewaan</h6>
        <div style="position: relative; height:300px;">
            <canvas id="penyewaanChart"></canvas>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { labels: { color: 'white' } },
            tooltip: { bodyColor: 'white', titleColor: 'white' }
        },
        scales: {
            x: {
                ticks: { color: 'white' },
                grid: { color: 'rgba(255,255,255,0.2)' }
            },
            y: {
                ticks: { color: 'white' },
                grid: { color: 'rgba(255,255,255,0.2)' }
            }
        }
    };

    // Statistik Kategori
    new Chart('kategoriChart', {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($kategoriStat->pluck('kategori')); ?>,
            datasets: [{ label:'Jenis', data:<?php echo json_encode($kategoriStat->pluck('total')); ?>, backgroundColor:['white'] }]
        },
        options: chartOptions
    });

    // Statistik Barang
    new Chart('barangChart', {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($barangStat->pluck('nama_barang')); ?>,
            datasets: [{ label:'Disewa', data:<?php echo json_encode($barangStat->pluck('total')); ?>, backgroundColor:'white' }]
        },
        options: chartOptions
    });

    // Data Penyewaan Bulanan
    const bulanLabels = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
    const penyewaanData = Array(12).fill(0);
    <?php $__currentLoopData = $penyewaanStat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      penyewaanData[<?php echo e($stat->bulan - 1); ?>] = <?php echo e($stat->total); ?>;
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    new Chart('penyewaanChart', {
        type: 'bar',
        data: { labels: bulanLabels, datasets:[{ label:'Penyewaan', data: penyewaanData, backgroundColor:['White'] }]},
        options: chartOptions
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\DIFAS-App\resources\views\dashboard.blade.php ENDPATH**/ ?>