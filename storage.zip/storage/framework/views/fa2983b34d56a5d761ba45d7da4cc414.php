<?php $__env->startSection('title', 'Form Tambah Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-wrapper justify-content-center"> 
    <div class="bg-primary card p-4 position-relative" style="border-radius: 15px; width: 100%;">

        <div class="text-center mb-4">
            <h4 class="text-white fw-bold m-0">FORM TAMBAH BARANG</h4>
        </div>

        <!-- Alert Success -->
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Alert Error -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Data tidak bisa disimpan!</strong>
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Form di dalam container putih -->
        <div class="card p-3 bg-secondary">
            <form action="<?php echo e(route('barang.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label class="form-label">Foto Barang (JPG, JPEG, PNG)</label>
                    <input type="file" name="foto" class="form-control" accept="image/jpeg,image/png">
                </div>

                <div class="mb-3">
                    <label class="form-label">Nama Barang</label>
                    <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama')); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Kategori Barang</label>
                    <select name="kategori" class="form-select" required>
                        <option value="">-- Pilih Kategori --</option>
                        <?php
                            $kategoriList = ['Tenda ', 'Kursi', 'Meja', 'Taplak Meja', 'Panggung', 'Soundsystem'];
                        ?>
                        <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kategori); ?>" <?php echo e(old('kategori') == $kategori ? 'selected' : ''); ?>>
                                <?php echo e($kategori); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Harga Sewa</label>
                    <input type="number" name="harga_sewa" class="form-control" value="<?php echo e(old('harga_sewa')); ?>" min="1" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Stok</label>
                    <input type="number" name="stok" class="form-control" value="<?php echo e(old('stok')); ?>" min="1" required>
                </div>

                <div class="text-center mt-3">
                    <button type="submit" class="btn btn-primary fw-semibold">Simpan</button>
                    <button type="reset" class="btn btn-secondary fw-semibold">Batalkan</button>                           
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\DIFAS-App\resources\views\barang\create.blade.php ENDPATH**/ ?>