<?php $__env->startSection('title', 'Report Pesanan'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-wrapper justify-content-center"> 
    <div class="bg-primary card p-4 position-relative" style="border-radius: 15px; width: 100%;">

        <!-- Form gabungan search dan filter tanggal -->
        <form method="GET" action="<?php echo e(route('report.index')); ?>">
            <div class="d-flex justify-content-between align-items-end flex-wrap gap-3 mb-4">
                
                <!-- Judul -->
                <div class="flex-grow-1">
                    <h4 class="text-white fw-bold m-0">REPORT PENYEWAAN</h4>
                </div>

                <!-- Input tanggal mulai dan akhir -->
                <div class="d-flex gap-2 flex-wrap">
                    <input type="date" name="tanggal_mulai" value="<?php echo e(request('tanggal_mulai')); ?>" class="form-control" style="width: 150px;">
                    <span class="text-white align-self-center fw-semibold">Sampai</span>
                    <input type="date" name="tanggal_akhir" value="<?php echo e(request('tanggal_akhir')); ?>" class="form-control" style="width: 150px;">  
                    <button class="btn btn-primary fw-semibold" type="submit">Cari</button>
                    <a href="<?php echo e(route('report.index')); ?>" class="btn btn-secondary fw-semibold">Reset</a>
                </div>
            </div>
        </form>
        <div class="table-responsive">
            <table class="table table-bordered table-striped text-center align-middle bg-white">
                <thead class="table-primary" style="position: sticky; top: 0;">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>ID Pesanan</th>
                        <th>Nama Pemesan</th>
                        <th>Kode Barang</th>
                        <th>Deskripsi</th>
                        <th>Jumlah</th>
                        <th>Subtotal</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $total = $p->getTotalDariDetailAttribute();
                            $rowCount = $p->details->count();
                            
                            $totalRows = $rowCount + 2;
                        ?>
            
                        
                        <tr>
                            <td rowspan="<?php echo e($totalRows); ?>"><?php echo e($index + 1); ?></td>
                            <td rowspan="<?php echo e($totalRows); ?>"><?php echo e(\Carbon\Carbon::parse($p->tanggal_acara)->format('d-m-Y')); ?></td>
                            <td rowspan="<?php echo e($totalRows); ?>"><?php echo e($p->id); ?></td>
                            <td rowspan="<?php echo e($totalRows); ?>"><?php echo e($p->nama_pemesan); ?></td>
                            <td colspan="4" style="height: 10px;"></td>
                            <td rowspan="<?php echo e($totalRows); ?>">Rp<?php echo e(number_format($total)); ?></td>
                        </tr>
            
                        
                        <?php $__currentLoopData = $p->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($d->barang_id); ?></td>
                                <td><?php echo e($d->nama_barang); ?></td>
                                <td><?php echo e($d->jumlah); ?></td>
                                <td>Rp<?php echo e(number_format($d->subtotal)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="4" style="height: 10px;"></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9">Belum ada data pesanan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <div class="text-center mt-4">
            <a href="<?php echo e(route('report.penyewaan.pdf', 
            ['tanggal_mulai' => request('tanggal_mulai'),'tanggal_akhir' => request('tanggal_akhir')])); ?>" 
            class="btn btn-primary fw-semibold">Cetak</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\DIFAS-App\resources\views\report\index.blade.php ENDPATH**/ ?>