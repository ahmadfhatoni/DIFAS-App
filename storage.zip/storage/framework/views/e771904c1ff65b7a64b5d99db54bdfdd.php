<?php $__env->startSection('title', 'Form Edit Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-wrapper justify-content-center"> 
    <div class="bg-primary card p-4 position-relative" style="border-radius: 15px; width: 100%;">

        <div class="text-center mb-4">
            <h4 class="text-white fw-bold m-0">FORM EDIT BARANG</h4>
        </div>

        <!-- Alert Error -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Data tidak bisa disimpan!</strong>
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Alert Success -->
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Form -->
        <div class="card p-3 bg-secondary">
            <form action="<?php echo e(route('barang.update', $barang->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label class="form-label">ID Barang</label>
                    <input type="text" class="form-control" value="<?php echo e($barang->id); ?>" disabled>
                </div>

                <div class="mb-3">
                    <label class="form-label">Foto Barang (JPG, JPEG, PNG)</label><br>
                    <?php if($barang->foto): ?>
                        <img src="<?php echo e(asset($barang->foto)); ?>" width="100" class="mb-2 rounded">
                    <?php endif; ?>
                    <input type="file" name="foto" class="form-control" accept="image/jpeg,image/png">
                    <small class="text-muted">Kosongkan jika tidak ingin mengganti foto.</small>
                </div>

                <div class="mb-3">
                    <label class="form-label">Nama Barang</label>
                    <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama', $barang->nama)); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Kategori Barang</label>
                    <select name="kategori" class="form-select" required>
                        <option value="">-- Pilih Kategori --</option>
                        <?php
                            $kategoriList = ['Tenda ', 'Kursi', 'Meja', 'Taplak Meja', 'Panggung', 'Soundsystem'];
                        ?>
                        <?php $__currentLoopData = $kategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kategori); ?>" <?php echo e(old('kategori', $barang->kategori) == $kategori ? 'selected' : ''); ?>>
                                <?php echo e($kategori); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Harga Sewa</label>
                    <input type="number" name="harga_sewa" class="form-control" min="1" value="<?php echo e(old('harga_sewa', $barang->harga_sewa)); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Stok</label>
                    <input type="number" name="stok" class="form-control" min="1" value="<?php echo e(old('stok', $barang->stok)); ?>" required>
                </div>

                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-primary mb-3 fw-semibold">Simpan Perubahan</button>
                    <a href="<?php echo e(route('barang.index')); ?>" class="btn btn-secondary mb-3 fw-semibold">Batalkan</a>
                </div>
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\DIFAS-App\resources\views\barang\edit.blade.php ENDPATH**/ ?>